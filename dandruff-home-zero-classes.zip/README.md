# Dandruff — zero-class Home screen

This zip contains a drop-in Expo / React Native home screen matching the restrained dark UI discussed in chat.

## Files

- `src/app/index.tsx` — the home screen

This assumes your project uses **Expo Router**, which matches the `src/app/index.tsx` structure visible in your current project.

## Install / use

1. Make a backup of your current:
   `src/app/index.tsx`

2. Copy the included `src/app/index.tsx` into your project.

3. Start Expo:
   `npx expo start`

## Existing dependencies used

The screen only uses packages normally included with an Expo Router project:

- `react`
- `react-native`
- `react-native-safe-area-context`
- `expo-status-bar`
- `@expo/vector-icons`

If `@expo/vector-icons` is somehow missing, run:

`npx expo install @expo/vector-icons`

## Connect it to your existing functionality

At the top of `HomeScreen`, there are three clearly marked handlers:

- `handleAddClass`
- `handleImportSchedule`
- `handleOpenSettings`

Replace their temporary `Alert.alert(...)` calls with your existing navigation / backend functions.

## Initial state

This version intentionally starts with:

- `0 classes`
- no Next Class section
- a restrained empty state
- Add class
- Import schedule screenshot

No new backend functionality is introduced.
