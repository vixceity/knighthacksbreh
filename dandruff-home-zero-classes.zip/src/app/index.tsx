import React from "react";
import {
  Alert,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { Ionicons } from "@expo/vector-icons";

export default function HomeScreen() {
  // Replace these three handlers with your existing navigation / backend logic.
  const handleAddClass = () => {
    Alert.alert("Add class", "Connect this button to your existing add-class flow.");
  };

  const handleImportSchedule = () => {
    Alert.alert(
      "Import schedule",
      "Connect this button to your existing screenshot-import flow."
    );
  };

  const handleOpenSettings = () => {
    Alert.alert("Settings", "Connect this button to your existing settings screen.");
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "left", "right"]}>
      <StatusBar style="light" />

      <View style={styles.screen}>
        <View style={styles.headerRow}>
          <View style={styles.headerText}>
            <Text style={styles.appName}>Dandruff</Text>
            <Text style={styles.tagline}>don&apos;t flake on your classes</Text>
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open settings"
            onPress={handleOpenSettings}
            hitSlop={12}
            style={({ pressed }) => [
              styles.settingsButton,
              pressed && styles.pressed,
            ]}
          >
            <Ionicons name="settings-outline" size={27} color="#A7A7AE" />
          </Pressable>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Your classes</Text>
          <Text style={styles.classCount}>0 classes</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.emptyState}>
          <Text style={styles.emptyTitle}>No classes yet</Text>
          <Text style={styles.emptyBody}>
            Add your first class or import a schedule screenshot.
          </Text>
        </View>

        <View style={styles.actions}>
          <Pressable
            accessibilityRole="button"
            onPress={handleAddClass}
            style={({ pressed }) => [
              styles.primaryButton,
              pressed && styles.primaryPressed,
            ]}
          >
            <Ionicons name="add" size={24} color="#FFFFFF" />
            <Text style={styles.primaryButtonText}>Add class</Text>
          </Pressable>

          <Pressable
            accessibilityRole="button"
            onPress={handleImportSchedule}
            style={({ pressed }) => [
              styles.secondaryButton,
              pressed && styles.pressed,
            ]}
          >
            <Ionicons name="image-outline" size={21} color="#5A9CFF" />
            <Text style={styles.secondaryButtonText}>
              Import schedule screenshot
            </Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#0B0B0C",
  },

  screen: {
    flex: 1,
    backgroundColor: "#0B0B0C",
    paddingHorizontal: 24,
    paddingTop: 28,
  },

  headerRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },

  headerText: {
    flexShrink: 1,
  },

  appName: {
    color: "#F5F5F7",
    fontSize: 38,
    lineHeight: 44,
    fontWeight: "700",
    letterSpacing: -1.2,
  },

  tagline: {
    marginTop: 4,
    color: "#9B9BA2",
    fontSize: 18,
    lineHeight: 24,
    fontWeight: "400",
  },

  settingsButton: {
    paddingTop: 8,
    paddingLeft: 16,
  },

  sectionHeader: {
    marginTop: 64,
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "space-between",
  },

  sectionTitle: {
    color: "#F5F5F7",
    fontSize: 27,
    lineHeight: 33,
    fontWeight: "700",
    letterSpacing: -0.5,
  },

  classCount: {
    color: "#77777F",
    fontSize: 15,
    lineHeight: 20,
    fontWeight: "400",
  },

  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: "#2A2A2D",
    marginTop: 16,
  },

  emptyState: {
    paddingTop: 34,
    paddingBottom: 42,
  },

  emptyTitle: {
    color: "#D6D6DA",
    fontSize: 18,
    lineHeight: 24,
    fontWeight: "600",
  },

  emptyBody: {
    marginTop: 8,
    maxWidth: 290,
    color: "#85858D",
    fontSize: 16,
    lineHeight: 23,
    fontWeight: "400",
  },

  actions: {
    marginTop: "auto",
    paddingBottom: 28,
    gap: 14,
  },

  primaryButton: {
    minHeight: 54,
    borderRadius: 12,
    backgroundColor: "#2F80ED",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },

  primaryPressed: {
    opacity: 0.84,
  },

  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 18,
    lineHeight: 23,
    fontWeight: "600",
  },

  secondaryButton: {
    minHeight: 48,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },

  secondaryButtonText: {
    color: "#5A9CFF",
    fontSize: 16,
    lineHeight: 21,
    fontWeight: "500",
  },

  pressed: {
    opacity: 0.65,
  },
});
